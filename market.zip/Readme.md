# Chat APP
## Usage
1. Install docker and docker-compose,
2. use ``cp .env.example .env`` to make a copy of env file
3. use ``docker-compose up`` to start the app

 App is now accessible on ``localhost:8080``